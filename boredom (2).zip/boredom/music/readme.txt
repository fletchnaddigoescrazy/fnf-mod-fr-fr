!!THIS ISN'T WHERE YOU PUT YOUR SONGS!!
!!YOU PUT THEM IN SONGS/!!

Put your music here!
(To be more specific, game over music (the beginning, loop and end), cutscene music, etc.)
Said music can also be played through Lua, using playSound.